package jdbc;

import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class MonResultSet implements ResultSet {
    private Map<String, Object> data = new HashMap<>(); // Simuler les données d'une ligne
    private boolean closed = false;

    // Ajouter des données pour simuler les résultats d'une requête
    public void addData(String columnLabel, Object value) {
        data.put(columnLabel, value);
    }

    @Override
    public <T> T getObject(String columnLabel, Class<T> type) throws SQLException {
        if (closed) {
            throw new SQLException("Le ResultSet est fermé");
        }

        // Récupérer la valeur de la colonne spécifiée
        Object value = data.get(columnLabel);
        if (value == null) {
            return null;  // Si la valeur est null, renvoyer null
        }

        // Vérifier si la valeur peut être convertie en type demandé
        if (!type.isInstance(value)) {
            throw new SQLException("Impossible de convertir la valeur en type " + type.getName());
        }

        return type.cast(value);  // Retourner la valeur convertie
    }

    // Méthodes à implémenter pour rendre le ResultSet fonctionnel
    @Override
    public boolean next() throws SQLException {
        // Simuler la navigation dans les résultats (dans cet exemple, il n'y a qu'une seule ligne)
        return !closed;
    }

    @Override
    public void close() throws SQLException {
        closed = true;
    }

    // Implémenter d'autres méthodes nécessaires...
}