package jdbc;

import java.sql.*;

public class MonConnection implements Connection {

    private String url;
    private int networkTimeout = 30000;  // Valeur par défaut du timeout en millisecondes (30 secondes)

    public MonConnection(String url) {
        this.url = url;
    }

    // Implémentation de la méthode getNetworkTimeout
    @Override
    public int getNetworkTimeout() throws SQLException {
        return networkTimeout;  // Retourne le timeout configuré
    }

    // Les autres méthodes de Connection, comme createStatement, etc...
    
    @Override
    public Statement createStatement() throws SQLException {
        return new MonStatement();  // Retourne une instance de MonStatement
    }

    @Override
    public PreparedStatement prepareStatement(String sql) throws SQLException {
        return null;  // Non implémenté
    }

    @Override
    public CallableStatement prepareCall(String sql) throws SQLException {
        return null;  // Non implémenté
    }

    @Override
    public String nativeSQL(String sql) throws SQLException {
        return sql;  // Retourne la requête sans modification
    }

    @Override
    public void setAutoCommit(boolean autoCommit) throws SQLException {
        // Pas de gestion pour auto-commit ici
    }

    @Override
    public boolean getAutoCommit() throws SQLException {
        return true;  // Retourne toujours true pour simplifier
    }

    @Override
    public void commit() throws SQLException {
        // Non implémenté
    }

    @Override
    public void rollback() throws SQLException {
        // Non implémenté
    }

    @Override
    public void close() throws SQLException {
        System.out.println("Connexion fermée.");
    }

    @Override
    public boolean isClosed() throws SQLException {
        return false;  // Par défaut
    }

    // Ajoute d'autres méthodes si nécessaire...
}