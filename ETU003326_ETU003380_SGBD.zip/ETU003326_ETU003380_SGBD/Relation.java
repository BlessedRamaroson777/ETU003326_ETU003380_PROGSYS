package firaisana;

import java.io.File;
import java.io.FilenameFilter;
import java.util.regex.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Vector;

import java.rmi.server.ServerCloneException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.FileHandler;

import javax.smartcardio.ATR;
import save.*;
import org.w3c.dom.Attr;

import fitambarana.Ensemble;

public class Relation extends Ensemble{
    Vector<Attribut> attribut;
    String nom;

    public Relation(String nom, Vector<Attribut> att, Vector<Vector<Object>> nup) {
        super(new Attribut().nupletValid(att, nup));  
        this.attribut = att;
        this.nom = nom;
    }

    public Relation(){
        super(new Vector<Vector<Object>>());
    }

    public Vector<Attribut> getAttribut(){
        return this.attribut;
    }

    public String getNom(){
        return this.nom;
    }

    public void addAttribut(Attribut nouveau){
        this.attribut.addElement(nouveau);
    }

    public void deleteAttribut(String fafana){
        for(int i=0;i<this.attribut.size();i++){
            if(this.attribut.elementAt(i).getNom().equals(fafana)){
                this.attribut.remove(i);
            }
        }
    }
    
    public boolean addNuplet(Vector<Object> all){
        int a=0;
        for(int i=0;i<this.attribut.size();i++){
            if(this.attribut.elementAt(i).isValid(all.elementAt(i))){
                a++;
            }
            else{
                return false;
            }
        }
        if(a==this.attribut.size()){
            super.add(all);
            return true;
        }
        else{
            return false;
        }
    }

    public boolean addNuplet(String request){
        Vector<Object> all=addNupletString(request);
        int a=0;
        for(int i=0;i<this.attribut.size();i++){
            if(this.attribut.elementAt(i).isValid(all.elementAt(i))){
                a++;
            }
            else{
                return false;
            }
        }
        if(a==this.attribut.size()){
            super.add(all);
            return true;
        }
        else{
            return false;
        }
    }

    public static Class<?> getContainerType(Class<?> class1, Class<?> class2) {
        // Si les deux classes sont null
        if (class1 == null && class2 == null) {
            return null;
        }
    
        // Si l'une des classes est null, retourner l'autre
        if (class1 == null) {
            return class2;
        }
        if (class2 == null) {
            return class1;
        }
    
        // Gestion des types primitifs et objets
        if ((class1 == boolean.class || class1 == Boolean.class) &&
            (class2 == int.class || class2 == Integer.class)) {
            // Retourner String pour les contenir sous forme textuelle
            return String.class;
        }
        if ((class2 == boolean.class || class2 == Boolean.class) &&
            (class1 == int.class || class1 == Integer.class)) {
            // Retourner String pour les contenir sous forme textuelle
            return String.class;
        }
    
        // Gestion des types primitifs
        if (class1.isPrimitive() && class2.isPrimitive()) {
            // Gérer les types int, float, double, et boolean
            if (class1 == int.class || class1 == Integer.class) {
                if (class2 == double.class || class2 == Double.class) {
                    return double.class;  // double est plus large que int
                } else if (class2 == float.class || class2 == Float.class) {
                    return float.class;   // float est plus large que int
                } else {
                    return int.class;  // Retourner int si class2 est un autre type numérique
                }
            }
    
            // Gérer les types double et float
            if (class1 == double.class || class1 == Double.class) {
                return double.class;  // Double est plus large que tous les types int et float
            }
    
            if (class1 == float.class || class1 == Float.class) {
                return float.class;  // Retourner float si aucun type double n'est impliqué
            }
    
            // Gérer le type boolean
            if (class1 == boolean.class || class2 == boolean.class) {
                return boolean.class;  // Si un des deux types est boolean, retourner boolean
            }
    
            // Gérer les autres types primitifs (byte, char, short, long)
            return class1;  // Par défaut, retourner class1 si aucun cas spécifique n'a été rencontré
        }
    
        // Gestion des types Number (Integer, Double, etc.) lorsque l'un des deux n'est pas primitif
        if (Number.class.isAssignableFrom(class1) && Number.class.isAssignableFrom(class2)) {
            if (class1 == Double.class || class2 == Double.class) {
                return Double.class;  // Double est plus large que Integer, Float, etc.
            }
            if (class1 == Float.class || class2 == Float.class) {
                return Float.class;  // Float est plus large que Integer
            }
            if (class1 == Long.class || class2 == Long.class) {
                return Long.class;  // Long est plus large que Integer
            }
            if (class1 == Integer.class || class2 == Integer.class) {
                return Integer.class;  // Integer est le plus petit des types numériques
            }
            return class1;  // Par défaut, retourner class1 si aucune autre conversion n'est nécessaire
        }
    
        // Gestion des chaînes de caractères
        if (class1 == String.class || class2 == String.class) {
            return String.class;  // Si l'un des deux types est String, retourner String
        }
    
        // Par défaut, retourner Object si aucun autre type approprié n'est trouvé
        return Object.class;
    }       
    
    public Vector<Attribut> getAttributContain(Relation another){
        Vector<Attribut> att=new Vector<Attribut>();
        for(int i=0;i<this.attribut.size();i++){
            String nom=(this.attribut.elementAt(i).getNom());
            Class one=this.attribut.elementAt(i).getDomaine();
            Class two=another.attribut.elementAt(i).getDomaine();
            Class domaine=getContainerType(one,two);
            Vector<Object> valiny=new Vector<Object>();
            if(this.attribut.elementAt(i).getEnsDomaine()!=null){
                valiny=this.attribut.elementAt(i).getEnsDomaine().getElement();
            }
            if(another.attribut.elementAt(i).getEnsDomaine()!=null){
                valiny.addAll(another.attribut.elementAt(i).getEnsDomaine().getElement());
            }
            Ensemble inona=new Ensemble(valiny);
            Attribut neuf=new Attribut(nom, domaine, inona);
            att.addElement(neuf);
        }
        return att;
    }
    
    public Relation union(Relation one){
        if(this.attribut.size()==one.attribut.size()){
            Ensemble a=this.union((Ensemble)one); 
            Vector<Attribut> att=this.getAttributContain(one);
            Relation nouveau=new Relation(this.getNom(), att, a.getElement());
            return nouveau;
        }
        return null;
    }
    
    public Relation intersection(Relation one){
        if(this.attribut.size()==one.attribut.size()){
            Ensemble a=this.intersection((Ensemble)one); 
            Vector<Attribut> att=this.getAttributContain(one);
            Relation nouveau=new Relation(this.getNom(), att, a.getElement());            
            return nouveau;
        }
        return null;
    }

    public Relation difference(Relation one) {
        if(this.attribut.size()==one.attribut.size()){
            Ensemble a=this.difference((Ensemble)one); 
            Vector<Attribut> att=this.getAttributContain(one);
            Relation nouveau=new Relation(this.getNom(), att, a.getElement());
            return nouveau;
        }
        return null;
    }
    
    public Relation projection(Vector<String> colonne) {
        Vector<Attribut> att = new Vector<>();
        Vector<Vector<Object>> futur = new Vector<>();
        Vector<Integer> indice = new Vector<>();
    
        for (int i = 0; i < colonne.size(); i++) {
            for (int j = 0; j < this.attribut.size(); j++) {
                if (this.attribut.elementAt(j).getNom().equals(colonne.elementAt(i))) {
                    att.addElement(this.attribut.elementAt(j));
                    indice.addElement(j);
                }
            }
        }
    
        if (super.getElement() != null) {
            for (int i = 0; i < super.getElement().size(); i++) {
                Vector<Object> inona = new Vector<>();
                for (int k = 0; k < indice.size(); k++) {
                    inona.addElement(((Vector<Object>)super.getElement().elementAt(i)).elementAt(indice.elementAt(k)));
                }
                futur.addElement(inona);
            }
        }
    
        Relation valiny = new Relation(this.getNom(), att, futur);
        return valiny;
    }

    public Relation produitCartesien(Relation one) {
        Vector<Attribut> att = new Vector<>(this.attribut);
        att.addAll(one.attribut); 
        Vector<Vector<Object>> nup = new Vector<>(); 
        for (int a = 0; a < this.getElement().size(); a++) {
            Vector<Object> thisElement = (Vector<Object>)this.getElement().elementAt(a);
            for (int i = 0; i < one.getElement().size(); i++) {
                Vector<Object> oneElement = (Vector<Object>)one.getElement().elementAt(i);
                Vector<Object> newRow = new Vector<>(thisElement); 
                newRow.addAll(oneElement);  
                nup.add(newRow);
            }
        }
        Relation valiny = new Relation(this.getNom(), att, nup);
        return valiny;
    }
    
    public Vector<String> separeRequete(String input) {
        String regex="(<=|>=|!=|=|<|>)";
        String[] parts=input.split(regex);
        if (parts.length != 2) {
            return null;
        }
        Vector<String> result=new Vector<>();
        result.add(parts[0].trim());
        result.add(input.replaceAll(".*?(<=|>=|!=|=|<|>).*", "$1").trim());
        result.add(parts[1].trim());
        return result;
    }

    public Relation selectionOne(String requete) {   //selection avec une comparaison en valeur
        Vector<String> all=separeRequete(requete);
        String colonne=all.elementAt(0);
        String condition=all.elementAt(1);
        String compare=all.elementAt(2);
        Vector<Vector<Object>> nup=new Vector<Vector<Object>>();    
        for (int j=0; j<this.getElement().size(); j++) {
            for (int i=0; i<this.attribut.size(); i++) {
                if (this.attribut.elementAt(i).getNom().equals(colonne)) {
                    Object valeur=((Vector<Object>) this.getElement().elementAt(j)).elementAt(i);
                    Class<?> domaine=this.attribut.elementAt(i).getDomaine();
    
                    if (domaine == String.class) {
                        String valeurStr=(String) valeur;
    
                        if (condition.equals("=") && valeurStr.equals(compare)) {
                            nup.addElement((Vector<Object>)this.getElement().elementAt(j));
                        } else if (condition.equals("!=") && !valeurStr.equals(compare)) {
                            nup.addElement((Vector<Object>)this.getElement().elementAt(j));
                        }
                    }
    
                    else if (domaine == Integer.class) {
                        int valeurInt=(Integer) valeur;
                        int compareInt=Integer.parseInt(compare);  
    
                        if (condition.equals("=") && valeurInt == compareInt) {
                            nup.addElement((Vector<Object>)this.getElement().elementAt(j));
                        } else if (condition.equals("!=") && valeurInt != compareInt) {
                            nup.addElement((Vector<Object>)this.getElement().elementAt(j));
                        } else if (condition.equals("<") && valeurInt<compareInt) {
                            nup.addElement((Vector<Object>)this.getElement().elementAt(j));
                        } else if (condition.equals("<=") && valeurInt <= compareInt) {
                            nup.addElement((Vector<Object>)this.getElement().elementAt(j));
                        } else if (condition.equals(">") && valeurInt > compareInt) {
                            nup.addElement((Vector<Object>)this.getElement().elementAt(j));
                        } else if (condition.equals(">=") && valeurInt >= compareInt) {
                            nup.addElement((Vector<Object>)this.getElement().elementAt(j));
                        }
                    }
    
                    else if (domaine == Double.class) {
                        double valeurDouble=(Double) valeur;
                        double compareDouble=Double.parseDouble(compare);  
    
                        if (condition.equals("=") && valeurDouble == compareDouble) {
                            nup.addElement((Vector<Object>)this.getElement().elementAt(j));
                        } else if (condition.equals("!=") && valeurDouble != compareDouble) {
                            nup.addElement((Vector<Object>)this.getElement().elementAt(j));
                        } else if (condition.equals("<") && valeurDouble<compareDouble) {
                            nup.addElement((Vector<Object>)this.getElement().elementAt(j));
                        } else if (condition.equals("<=") && valeurDouble <= compareDouble) {
                            nup.addElement((Vector<Object>)this.getElement().elementAt(j));
                        } else if (condition.equals(">") && valeurDouble > compareDouble) {
                            nup.addElement((Vector<Object>)this.getElement().elementAt(j));
                        } else if (condition.equals(">=") && valeurDouble >= compareDouble) {
                            nup.addElement((Vector<Object>)this.getElement().elementAt(j));
                        }
                    }
    
                    else {
                        System.out.println("Type de donnée non supporté pour la comparaison.");
                    }
                }
            }
        }
        
        Relation valiny=new Relation(this.nom, this.attribut, nup);
        return valiny;
    }

    public Relation selectionTwo(String requete) {  //selection avec colonne pour la comparaison
        Vector<String> all = separeRequete(requete);
        String colonne = all.elementAt(0);
        String condition = all.elementAt(1);
        String compare = all.elementAt(2);   
        Vector<Vector<Object>> nup = new Vector<Vector<Object>>();
    
        for (int j = 0; j < this.getElement().size(); j++) {
            for (int i = 0; i < this.attribut.size(); i++) {
                if (this.attribut.elementAt(i).getNom().equals(colonne)) {
                    Object valueToCompare = ((Vector<Object>) this.getElement().elementAt(j)).elementAt(i);
                    for (int a = i+1; a < this.attribut.size(); a++) {
                        if (this.attribut.elementAt(a).getNom().equals(compare)) {
                            Object compareValue = ((Vector<Object>) this.getElement().elementAt(j)).elementAt(a);
                            if (condition.equals("=") && valueToCompare.equals(compareValue) ||
                                condition.equals("!=") && !valueToCompare.equals(compareValue) ||
                                condition.equals("<") && ((Comparable) valueToCompare).compareTo(compareValue) < 0 ||
                                condition.equals("<=") && ((Comparable) valueToCompare).compareTo(compareValue) <= 0 ||
                                condition.equals(">") && ((Comparable) valueToCompare).compareTo(compareValue) > 0 ||
                                condition.equals(">=") && ((Comparable) valueToCompare).compareTo(compareValue) >= 0) {
                                nup.addElement((Vector<Object>) this.getElement().elementAt(j));
                            }
                        }
                    }
                }
            }
        }
        return new Relation(this.nom, this.attribut, nup);
    }

    public Relation selection(String requete) {
        Relation valiny;
        try {
            valiny = selectionOne(requete);
        } catch (NumberFormatException e) {
            System.out.println("Erreur de format lors de la sélection avec selectionOne : " + e.getMessage());
            valiny = selectionTwo(requete);
        } catch (Exception e) {
            System.out.println("Une erreur s'est produite lors de la sélection avec selectionOne : " + e.getMessage());
            valiny = selectionTwo(requete);
        }    
        return valiny;
    }
    
    public Relation selection(Vector<String> requete) {
        Relation valiny=selection(requete.elementAt(0));
        if(requete.size()>1){
            for(int i=1;i<requete.size();i++){
                valiny=valiny.selectionOne(requete.elementAt(i));
            }
        }
        return valiny;
    }

    public Relation selection(Vector<String> requete1, String liaison, Vector<String> requete2){
        Relation a1=selection(requete1);
        Relation a2=selection(requete2);
        Vector<Vector<Object>> nup=new Vector<Vector<Object>>();
        if(liaison.equals("and")){
            for(int i=0;i<a1.getElement().size();i++){
                for(int j=0;j<a2.getElement().size();j++){
                    if(a1.getElement().elementAt(i).equals(a2.getElement().elementAt(j))){
                        nup.add((Vector<Object>)getElement().elementAt(i));
                    }
                }
            }
        }
        else if(liaison.equals("or")){
            Set<Vector<Object>> set = new HashSet<>();
            set.addAll(a1.getElement());
            set.addAll(a2.getElement());
            nup.addAll(set);
        }
        else{
            System.out.println("Cette liaison de requete ne peut etre effectue");
        }
        Relation valiny=new Relation(this.nom, a1.attribut, nup);
        return valiny;
    }

    public Relation selection(String requete1, String liaison, String requete2){
        Relation a1=selection(requete1);
        Relation a2=selection(requete2);
        if(liaison.equals("and")){
            return a1.intersection(a2);
        }
        else if(liaison.equals("or")){
            return a1.union(a2);
        }
        else{
            System.out.println("Cette liaison de requete ne peut etre effectue");
        }
        return null;
    }

    public Relation selectionLiaison(String requete){
        Vector<String> request=splitString(requete);
        if(request.size()>0){
            Relation valiny=selection(request.elementAt(0));
            int i=1;
            while(i<request.size()-1){
                Relation faharoa=selection(request.elementAt(i+1));
                if(request.elementAt(i).equals("and")){
                    valiny=valiny.intersection(faharoa);
                    i=i+2;
                }
                else if(request.elementAt(i).equals("or")){
                    valiny=valiny.union(faharoa);  
                    i=i+2;                  
                }
                else{
                    return null;
                }
            }
            return valiny;
        }
        return null;
    }

    public Relation readFromFile(String fileName) {
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName + ".txt"))) {
            // Lire la première ligne : les attributs
            Vector<Attribut> att = new Vector<>();
            String line = reader.readLine();
            if (line != null) {
                String[] attributs = line.split(",");
                for (int i = 0; i < attributs.length; i += 2) {
                    String nom = attributs[i].trim();
                    String domaine = attributs[i + 1].trim().replace("class ", "");
                    try {
                        // Ajouter l'attribut avec le nom et le domaine
                        att.add(new Attribut(nom, Class.forName(domaine), null));
                    } catch (Exception e) {
                        System.err.println("Erreur lors du chargement de la classe : " + domaine + ", " + e.getMessage());
                    }
                }
            }
    
            // Lire les lignes suivantes : les éléments
            Vector<Vector<Object>> all = new Vector<>();
            while ((line = reader.readLine()) != null) {
                String[] valeurs = line.split(",");
                Vector<Object> element = new Vector<>();
    
                for (int j = 0; j < valeurs.length; j++) {
                    String valeur = valeurs[j].trim();
                    try {
                        // Traiter la chaîne "null" comme la valeur null
                        if (valeur.equalsIgnoreCase("null") || valeur.isEmpty()) {
                            element.add(null); // Ajouter explicitement null
                        } else {
                            // Récupérer la classe correspondant à l'attribut
                            Class<?> domainClass = att.get(j).getDomaine();
                            
                            // Convertir la valeur selon le domaine
                            Object value = null;
                            if (domainClass == Integer.class) {
                                value = Integer.valueOf(valeur);
                            } else if (domainClass == Double.class) {
                                value = Double.valueOf(valeur);
                            } else if (domainClass == String.class) {
                                value = valeur;
                            } else if (domainClass == Boolean.class) {
                                value = Boolean.valueOf(valeur);
                            } else {
                                System.err.println("Type non pris en charge : " + domainClass.getName());
                            }
                            element.add(value); // Ajouter la valeur convertie
                        }
    
                    } catch (Exception e) {
                        // En cas d'erreur, ajouter null
                        System.err.println("Erreur de conversion pour la valeur : " + valeur + ", " + e.getMessage());
                        element.add(null);
                    }
                }
    
                // Ajouter l'élément à la liste
                all.add(element);
            }
    
            System.out.println("Relation reconstruite avec succès !");
            return new Relation(fileName, att, all); // Retourner la relation construite
    
        } catch (IOException e) {
            System.err.println("Erreur lors de la lecture du fichier : " + e.getMessage());
        }
        return null;
    }
    

    public void writeToFile(Relation content){

        String fileName = content.getNom();
        writeToFile(content, fileName);
    }

    public void writeToFile(Relation content, String fileName) {
        try {
    
            // Créer un fichier ou l'écraser s'il existe déjà
            File file = new File(fileName + ".txt");
            if (!file.exists()) {
                file.createNewFile(); // Crée le fichier s'il n'existe pas
                System.out.println("Fichier créé : " + fileName);
            }
    
            // Écrire dans le fichier (sans append)
            try (FileWriter writer = new FileWriter(file)) { // Pas de "true", écrasement du fichier
                // Écriture des attributs
                for (int i = 0; i < content.getAttribut().size(); i++) {
                    writer.write(content.getAttribut().elementAt(i).getNom() + "," +
                                 content.getAttribut().elementAt(i).getDomaine() + ",");
                }
                writer.write(System.lineSeparator());
    
                // Écriture des éléments
                for (int i = 0; i < content.getElement().size(); i++) {
                    Vector<Object> element = (Vector<Object>) content.getElement().elementAt(i);
                    for (int j = 0; j < element.size(); j++) {
                        Object valeur = element.elementAt(j);
    
                        // Vérifier si l'élément est un Integer, et l'écrire sans décimales
                        if (valeur instanceof Integer) {
                            writer.write(valeur.toString() + ",");
                        } else if (valeur instanceof Double) {
                            // Si c'est un Double, vérifier s'il est équivalent à un entier
                            Double valDouble = (Double) valeur;
                            if (valDouble == valDouble.intValue()) {
                                writer.write(valDouble.intValue() + ","); // Écrire sous forme d'Integer
                            } else {
                                writer.write(valeur + ","); // Sinon, écrire sous forme de Double
                            }
                        } else {
                            writer.write(valeur + ","); // Pour les autres types, conserver la conversion par défaut
                        }
                    }
                    writer.write(System.lineSeparator());
                }
                System.out.println("Contenu écrit avec succès !");
            }
        } catch (IOException e) {
            System.err.println("Erreur lors de la création ou de l'écriture dans le fichier : " + e.getMessage());
        }
    }

    public void deleteFile(String fileName) {
        // Créer un objet File à partir du nom du fichier
        File file = new File(fileName+".txt");
        
        // Vérifier si le fichier existe
        if (file.exists()) {
            // Supprimer le fichier
            if (file.delete()) {
                System.out.println("Table supprimé avec succès !");
            } else {
                System.out.println("Échec de la suppression du table.");
            }
        } else {
            System.out.println("Le table n'existe pas.");
        }
    }

    public void insertionString(String query, String user) {
        // Suppression des espaces inutiles autour de la chaîne
         query = query.trim();
    
         // Trouver la position du mot "VALUES" et diviser la chaîne
         int valuesIndex = query.toUpperCase().indexOf("VALUES");
    
         if (valuesIndex != -1) {
            // Extraire la partie avant "VALUES" pour obtenir le nom de la table
            String tableName = query.substring(0, valuesIndex).replaceAll("insert into", "").trim();
            tableName=user+"/"+tableName;
            // Extraire la partie entre parenthèses pour obtenir les valeurs
            String values = query.substring(valuesIndex + 6).trim(); // "VALUES" a une longueur de 6 caractères
            if (values.startsWith("(") && values.endsWith(")")) {
                values = values.substring(1, values.length() - 1).trim(); // Enlever les parenthèses
            }
            Relation test=readFromFile(tableName);
            new Relation().deleteFile(tableName);
            test.addNuplet(values);
            writeToFile(test, tableName);

            // Afficher les résultats
            System.out.println("Nom de la table: " + tableName);
            System.out.println("Valeurs à insérer: " + values);
         } else {
             System.out.println("Requête invalide.");
         }
    }

    public void deleteTableString(String query, String user) {
        // Supprimer les espaces inutiles autour de la chaîne
        query = query.trim();

        // Vérifier que la requête commence par "DROP TABLE" (insensible à la casse)
        if (query.toUpperCase().startsWith("DROP TABLE")) {
            // Extraire le nom de la table (tout ce qui vient après "DROP TABLE")
            String tableName = query.substring(10).trim();  // "DROP TABLE" fait 10 caractères
            tableName=user+"/"+tableName;
            deleteFile(tableName);
        } else {
            System.out.println("Requête invalide : Ce n'est pas une requête DROP TABLE.");
        }
    }

    public void deleteElement(String query, String user) {
        String tableName = "";
        String condition = "";

        // Vérifier si "WHERE" existe dans la requête
        int whereIndex = query.toUpperCase().indexOf("WHERE");
        
        // Extraire le nom de la table avant "WHERE" ou tout ce qui suit "FROM"
        if (whereIndex != -1) {
            tableName = query.substring(12, whereIndex).trim(); // "DELETE FROM" fait 12 caractères
            condition = query.substring(whereIndex + 5).trim(); // Après "WHERE"
        } else {
            tableName = query.substring(12).trim(); // Pas de "WHERE", donc tout après "DELETE FROM"
        }
        tableName=user+"/"+tableName;
        Relation a = readFromFile(tableName);
        Relation fafa = a;
        if(condition!=""){
            fafa=a.selectionLiaison(condition);
        }
        Relation valiny=a.difference(fafa);
        writeToFile(valiny);
    }

    public Object parseValue(String value) {
        // Supprimer les espaces inutiles autour de la valeur
        value = value.trim();
    
        // Tenter de convertir en Integer
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            // Si ce n'est pas un Integer, on continue avec d'autres types
        }
    
        // Tenter de convertir en Double
        try {
            return Double.parseDouble(value);
        } catch (NumberFormatException e) {
            // Si ce n'est pas un Double, on continue avec d'autres types
        }
    
        // Si ce n'est ni un Integer ni un Double, considérer comme String
        return value; // Retourner comme chaîne de caractères
    }
    
    
    public void updateTable(String query, String user) {
        // Initialisation des variables
        String tableName = "";
        String setValues = "";
        String condition = "";
    
        // Trouver l'indice de "SET" et "WHERE"
        int setIndex = query.toUpperCase().indexOf("SET");
        int whereIndex = query.toUpperCase().indexOf("WHERE");
    
        // Extraire le nom de la table (tout ce qui est après "UPDATE" et avant "SET")
        if (setIndex != -1) {
            tableName = query.substring(6, setIndex).trim(); // "UPDATE" fait 6 caractères
        } else {
            System.out.println("Requête UPDATE invalide. Aucun 'SET' trouvé.");
            return;
        }
    
        // Extraire les paires de valeurs après "SET" et avant "WHERE"
        if (whereIndex != -1) {
            setValues = query.substring(setIndex + 3, whereIndex).trim(); // "SET" fait 3 caractères
            condition = query.substring(whereIndex + 5).trim(); // Après "WHERE"
        } else {
            setValues = query.substring(setIndex + 3).trim(); // Pas de "WHERE", donc tout après "SET"
        }
    
        String[] setPairs = setValues.split(",");
        tableName=user+"/"+tableName;
            
        Relation moi2=readFromFile(tableName);
        Relation moi=moi2;
        if(!condition.equals("")){
            moi=moi2.selectionLiaison(condition);
        }
        Relation moi3=moi2.difference(moi);
        for (int i = 0; i < setPairs.length; i++) {
            // Séparer chaque paire en nom de colonne et valeur
            String[] keyValue = setPairs[i].split("=");
        
            if (keyValue.length == 2) {
                String columnName = keyValue[0].trim();  // Nom de la colonne
                String newValue = keyValue[1].trim();    // Nouvelle valeur
        
                // Convertir la nouvelle valeur selon son type (int, double, etc.)
                Object parsedValue = parseValue(newValue);
        
                // Vérifier si la colonne existe dans les attributs de la relation
                boolean columnExists = false;
                for (int k = 0; k < moi.attribut.size(); k++) {
                    if (moi.attribut.elementAt(k).getNom().equals(columnName)) {
                        columnExists = true;
                        break;
                    }
                }
        
                // Si la colonne existe, mettre à jour la valeur pour chaque élément de la relation
                if (columnExists) {
                    for (int j = 0; j < moi.getElement().size(); j++) {
                        Vector<Object> element = (Vector<Object>) moi.getElement().elementAt(j);
                        int columnIndex = -1;
        
                        // Trouver l'indice de la colonne
                        for (int k = 0; k < moi.attribut.size(); k++) {
                            if (moi.attribut.elementAt(k).getNom().equals(columnName)) {
                                columnIndex = k;
                                break;
                            }
                        }
        
                        // Mettre à jour la valeur dans l'élément
                        if (columnIndex != -1) {
                            element.set(columnIndex, parsedValue);
                        }
                    }
                } else {
                    System.out.println("Colonne non trouvée : " + columnName);
                }
            }
        }
        Relation muah=moi3.union(moi);        // Sauvegarder la relation mise à jour dans le fichier
        writeToFile(muah);
    }

    public void renameColumn(String tableName, String oldColumnName, String newColumnName) {
        try {
            Relation relation = readFromFile(tableName);

            boolean columnFound = false;
            for (Attribut attribut : relation.getAttribut()) {
                if (attribut.getNom().equalsIgnoreCase(oldColumnName)) {
                    attribut.setNom(newColumnName);
                    columnFound = true;
                    break;
                }
            }

            if (columnFound) {
                writeToFile(relation, tableName);
                System.out.println("La colonne " + oldColumnName + " a été renommée en " + newColumnName);
            } else {
                System.out.println("Erreur : La colonne " + oldColumnName + " n'existe pas.");
            }
        } catch (Exception e) {
            System.out.println("Erreur lors du renommage de la colonne : " + e.getMessage());
        }
    }

    public void dropColumnFromTable(String tableName, String columnName) {
        try {
            // Charger la relation depuis le fichier
            Relation relation = readFromFile(tableName);
    
            if (relation == null) {
                System.out.println("Erreur : Impossible de charger la relation " + tableName);
                return;
            }
    
            boolean columnFound = false;
    
            // Trouver l'index de la colonne à supprimer
            for (int i = 0; i < relation.getAttribut().size(); i++) {
                Attribut attribut = relation.getAttribut().get(i);
    
                if (attribut.getNom().equalsIgnoreCase(columnName)) {
                    // Supprimer l'attribut (colonne)
                    relation.getAttribut().remove(i);
    
                    // Supprimer la colonne correspondante dans toutes les lignes
                    for (Vector<Object> row : (Vector<Vector<Object>>)relation.getElement()) {
                        if (row != null) {
                            // Vérifier que la ligne a suffisamment d'éléments
                            if (i < row.size()) {
                                row.remove(i);
                            }
                        }
                    }
    
                    columnFound = true;
                    break;
                }
            }
    
            // Si la colonne a été supprimée, sauvegarder la relation
            if (columnFound) {
                writeToFile(relation, tableName);
                System.out.println("La colonne " + columnName + " a été supprimée de " + tableName);
            } else {
                System.out.println("Erreur : La colonne " + columnName + " n'existe pas.");
            }
    
        } catch (Exception e) {
            System.out.println("Erreur lors de la suppression de la colonne : " + e.getMessage());
            e.printStackTrace(); // Afficher la pile d'erreurs pour débogage
        }
    }
    

    public void addColumnToTable(String tableName, String columnName, String columnType) {
        try {
            Relation relation = readFromFile(tableName);

            for (Attribut attribut : relation.getAttribut()) {
                if (attribut.getNom().equalsIgnoreCase(columnName)) {
                    System.out.println("Erreur : Une colonne avec le nom " + columnName + " existe déjà.");
                    return;
                }
            }

            Attribut newColumn = new Attribut(columnName, mapColumnType(columnType));
            relation.getAttribut().add(newColumn);

            for (Vector<Object> row : (Vector<Vector<Object>>) relation.getElement()) {
                row.add(null);
            }

            writeToFile(relation, tableName);
            System.out.println("La colonne " + columnName + " a été ajoutée à " + tableName);
        } catch (IllegalArgumentException e) {
            System.out.println("Erreur : " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Erreur lors de l'ajout de la colonne : " + e.getMessage());
        }
    }

    private Class<?> mapColumnType(String columnType) throws IllegalArgumentException {
        switch (columnType.toUpperCase()) {
            case "STRING":
                return String.class;
            case "INTEGER":
                return Integer.class;
            case "DOUBLE":
                return Double.class;
            case "BOOLEAN":
                return Boolean.class;
            default:
                throw new IllegalArgumentException("Type de colonne non pris en charge : " + columnType);
        }
    }

    public void AlterTable(String requete, String user) {
        String[] partie = requete.trim().split("\\s+");

        if (partie.length < 4 || !partie[0].equalsIgnoreCase("ALTER") || !partie[1].equalsIgnoreCase("TABLE")) {
            System.out.println("Requête invalide. Format attendu : ALTER TABLE [nom_table] [action] ...");
            return;
        }

        String tableName = partie[2];
        tableName=user+"/"+tableName;
        try {
            if (partie[3].equalsIgnoreCase("ADD")) {
                if (partie.length > 5) {
                    String columnName = partie[4];
                    String columnType = partie[5];
                    addColumnToTable(tableName, columnName, columnType);
                } else {
                    System.out.println("Erreur : Les détails de la colonne à ajouter sont incomplets.");
                }
            } else if (partie[3].equalsIgnoreCase("TO")) {
                if (partie.length > 5) {
                    String oldColumnName = partie[4];
                    String newColumnName = partie[5];
                    renameColumn(tableName, oldColumnName, newColumnName);
                } else {
                    System.out.println("Erreur : Les détails de la colonne à renommer sont incomplets.");
                }
            } else if (partie[3].equalsIgnoreCase("DROP")) {
                if (partie.length > 4) {
                    String columnName = partie[4];
                    dropColumnFromTable(tableName, columnName);
                } else {
                    System.out.println("Erreur : Les détails de la colonne à supprimer sont incomplets.");
                }
            } else {
                System.out.println("Action invalide. Utilisez ADD, TO ou DROP.");
            }
        } catch (Exception e) {
            System.out.println("Erreur lors de l'exécution de la requête : " + e.getMessage());
        }
    }

    public void getAllTable(String request, String user){
        // Utilisation du répertoire courant
        File dossier = new File("./"+user+"/");
        if(request.equals("show tables")){
            // Vérifiez que c'est un dossier
            if (dossier.isDirectory()) {
                // Récupérez les fichiers .txt
                File[] fichiersTxt = dossier.listFiles(new FilenameFilter() {
                    @Override
                    public boolean accept(File dir, String name) {
                        return name.toLowerCase().endsWith(".txt");
                    }
                });
                Vector<Vector<Object>> all=new Vector<Vector<Object>>();

                // Affichez les fichiers trouvés
                if (fichiersTxt != null && fichiersTxt.length > 0) {
                    // System.out.println("Fichiers .txt trouvés :");
                    for (File fichier : fichiersTxt) {
                        int dernierPOint=fichier.getName().lastIndexOf('.');
                        if(dernierPOint>0){
                            Vector<Object> ha=new Vector<Object>();
                            ha.add(fichier.getName().substring(0, dernierPOint));
                            all.add(ha);
                        }
                        // System.out.println(fichier.getName());
                    }
                    Vector<Attribut> att=new Vector<Attribut>();
                    att.add(new Attribut("Tables", String.class));
                    Relation no=new Relation("Tables", att, all);
                    Relation sansHistory=no.selection("Tables!=historique_requetes");
                    sansHistory.afficheRelation();
                } else {
                    System.out.println("Aucune table trouvé.");
                }
            } else {
                System.out.println("Ce n'est pas un dossier !");
            }
        }
    }

    public static Vector<String> separeVirgule(String input) {
        // Divise la chaîne d'entrée en fonction des virgules
        String[] parts = input.split(",");

        // Créer une liste pour stocker les mots nettoyés
        Vector<String> result = new Vector<String>();

        // Parcours chaque élément et enlève les espaces inutiles
        for (String part : parts) {
            // Supprimer les espaces avant et après chaque mot, puis ajouter à la liste
            result.add(part.trim());
        }

        return result;
    }
    
    public void selectString(String query, String user) {
        // Vérifier si la requête contient 'WHERE'
    
        // Définir le motif commun pour SELECT FROM
        String regex = "select\\s+(.*?)\\s+from\\s+(.*?)(\\s+where\\s+(.*))?"; // Gestion du cas avec ou sans WHERE
        Pattern pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(query);
        
        if (matcher.matches()) {
            String columns = matcher.group(1).trim();  // Les colonnes sélectionnées (peut être '*' ou une liste)
            String tableName = matcher.group(2).trim(); // Nom de la table
            String whereClause = matcher.group(4); // Clause WHERE si présente (sinon null)
    
            // Si la requête contient des colonnes à sélectionner
            tableName=user+"/"+tableName;
            Relation test = readFromFile(tableName);
    
            // Si le '*' est spécifié, on récupère toutes les colonnes
            if (columns.equals("*")) {
                if (whereClause != null && !whereClause.isEmpty()) {
                    // Appliquer la clause WHERE si elle existe
                    test.selectionLiaison(whereClause).afficheRelation();
                } else {
                    // Sinon, afficher toutes les données sans WHERE
                    test.afficheRelation();
                }
            } else {
                // Gérer la sélection de colonnes spécifiques
                if (whereClause == null || whereClause.isEmpty()) {
                    test.projection(separeVirgule(columns)).afficheRelation(); // Avec WHERE
                } else {
                    Relation result = test.projection(separeVirgule(columns)); // Appliquer WHERE si présent
                    result.selectionLiaison(whereClause).afficheRelation(); // Pas de WHERE
                }
            }
        } else {
            System.out.println("Requête mal formée.");
        }
    }

    public String GetNomTable(String requete)
    {
        String[] elements = requete.split(" ");

        String Nomdutab = elements[2];

        return Nomdutab;
    }

    
    public void createTable(String requete, String user) {
        // Supprimer les espaces inutiles autour de la chaîne
        requete = requete.trim();
    
        // Extraire le nom de la table : ce qui se trouve entre 'create table' et '('
        String name = GetNomTable(user+"/"+requete);

        // Afficher le nom de la table pour le debug
        System.out.println("Nom de la table : " + name);
    
        // Extraire le contenu entre parenthèses (les colonnes)
        String contenuParentheses = requete.replaceAll("(?s).*\\((.*)\\).*", "$1").trim();
    
        // Afficher le contenu entre parenthèses pour le debug
        System.out.println("Contenu entre parenthèses : " + contenuParentheses);
    
        // Traitement des attributs à partir du contenu extrait entre parenthèses
        Vector<Attribut> Att = attributString(contenuParentheses);
    
        // Initialiser les lignes de la table (ici vide pour l'exemple)
        Vector<Vector<Object>> Row = new Vector<Vector<Object>>();
    
        // Créer l'objet Relation
        Relation vaovao = new Relation(name, Att, Row);
    
        // Sauvegarder l'objet Relation dans un fichier
        vaovao.writeToFile(vaovao, name);
    }
    
    public void voirHistorique(String user) {
        File logFile = new File(user+"/historique_requetes.txt");
    
        // Vérifier si le fichier existe
        if (!logFile.exists()) {
            System.out.println("Le fichier d'historique n'existe pas.");
            return;
        }
    
        // Lire et afficher le contenu du fichier
        try (BufferedReader reader = new BufferedReader(new FileReader(logFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);  // Afficher chaque ligne du fichier
            }
        } catch (IOException e) {
            System.err.println("Erreur lors de la lecture du fichier historique : " + e.getMessage());
        }
    }   
    
    public String[] separeUser(String requete){
        String[] meh=requete.split(";");
        return meh;
    }
    
    public void request(String prompt) {
        String[] meh=separeUser(prompt);
        if(meh.length==2){
            String requete=meh[0];
            String user=meh[1];
            try {
                if (requete.toLowerCase().startsWith("select")) {
                    this.selectString(requete, user);
                }
                else if (requete.toLowerCase().startsWith("drop table")) {
                    this.deleteTableString(requete, user);
                }
                else if (requete.toLowerCase().startsWith("insert into")) {
                    this.insertionString(requete, user);
                }
                else if (requete.toLowerCase().startsWith("delete from")) {
                    this.deleteElement(requete, user);
                }
                else if (requete.toLowerCase().startsWith("update")) {
                    this.updateTable(requete, user);
                }
                else if (requete.toLowerCase().equals("show tables")) {
                    this.getAllTable(requete, user);
                }
                else if (requete.toLowerCase().equals("show history")) {
                    this.voirHistorique(user);
                }
                else if (requete.toLowerCase().startsWith("alter table")) {
                    this.AlterTable(requete, user);
                }
                else if (requete.toLowerCase().startsWith("create table")) {
                    this.createTable(requete, user);
                }
                else {
                    System.out.println("Requête non reconnue : " + requete);
                }
            } catch (Exception e) {
                System.out.println("Erreur lors de l'exécution de la requête : " + e.getMessage());
            }
        }
        else{
            System.out.println("Erreur lors de l'identificatioon de l user");
        }
    }

    public static Vector<String> splitString(String input) {
        Vector<String> result = new Vector<>();
        StringBuilder currentSegment = new StringBuilder();
    
        // Parcours de chaque caractère de la chaîne d'entrée
        for (int i = 0; i < input.length(); i++) {
            char currentChar = input.charAt(i);
    
            // Si le caractère est un espace, on termine le segment actuel et on l'ajoute à la liste
            if (currentChar == ' ') {
                if (currentSegment.length() > 0) {
                    result.add(currentSegment.toString());
                    currentSegment.setLength(0);  // Réinitialiser le segment actuel
                }
            } else {
                // Ajouter le caractère au segment actuel
                currentSegment.append(currentChar);
            }
        }
    
        // Ajouter le dernier segment s'il y en a un
        if (currentSegment.length() > 0) {
            result.add(currentSegment.toString());
        }
    
        return result;
    }    

    public static Vector<Object> addNupletString(String texte) {
       
        Vector<Object> vector = new Vector<>();
        
        // Diviser la chaîne de caractères en fonction de la virgule
        String[] elements = texte.split(",");
        
        // Ajouter chaque élément dans miaraka amin'ny Type mifanaraka
        for (String element : elements) {
            element = element.trim();
            try {
                double valueDouble = Double.parseDouble(element);
                vector.add(valueDouble);
            } catch (NumberFormatException e1) {
                try {
                    int valueInt = Integer.parseInt(element);
                    vector.add(valueInt);  // Ajouter l'entier
                } catch (NumberFormatException e2) {
                     try {
                // Essayer de convertir l'élément en Float
                            float valueFloat = Float.parseFloat(element);
                        vector.add(valueFloat);
                            } catch (NumberFormatException e3) {
                        try {
                              if (element.equalsIgnoreCase("true") || element.equalsIgnoreCase("false")) {
                    boolean valueBoolean = Boolean.parseBoolean(element);
                    vector.add(valueBoolean);
                        } else {
                            vector.add(element);
                        }
                        } catch (Exception e4) {
                            // Si ce n'est ni un nombre, ni un booléen, l'ajouter en tant que String
                            vector.add(element);
                        }
                    }
                }
            }
        }
        
        return vector;
    }


    public Vector<Attribut> attributString(String input) {
        Vector<Attribut> result = new Vector<>();
        
        // Diviser les éléments séparés par des virgules
        String[] segments = input.split(",");
        
        for (String segment : segments) {
            // Supprimer les espaces superflus
            segment = segment.trim();
            
            // Diviser par un ou plusieurs espaces pour séparer le nom et le type
            String[] parts = segment.split("\\s+");
            
            if (parts.length == 2) {
                String attributeName = parts[0];
                String typeName = parts[1];
                
                // Convertir le type en Class (pour les types standard)
                Class<?> typeClass;
                switch (typeName) {
                    case "String":
                        typeClass = String.class;
                        break;
                    case "Integer":
                            typeClass = Integer.class;
                            break;
                    case "int":
                        typeClass = Integer.class;
                        break;
                    case "Double":
                        typeClass = Double.class;
                        break;
                    case "Float":
                        typeClass = Float.class;
                        break;
                    case "Boolean":
                        typeClass = Boolean.class;
                        break;
                    default:
                        throw new IllegalArgumentException("Type inconnu : " + typeName);
                }
                
                // Ajouter un nouvel objet Attribut
                result.add(new Attribut(attributeName, typeClass));
            } else {
                throw new IllegalArgumentException("Format invalide pour le segment : " + segment);
            }
        }
        
        return result;
    }
        

    public Relation jointureNaturelle(Relation one){
        Vector<String> same=new Vector<String>();
        Vector<Attribut> same2=new Vector<Attribut>();
        for(int i=0;i<one.attribut.size();i++){
            for(int j=0;j<this.attribut.size();j++){
                if(this.attribut.elementAt(i).equals(one.attribut.elementAt(j))){
                    same.addElement(one.attribut.elementAt(i).getNom());
                    same2.addElement(one.attribut.elementAt(i));
                }
            }
        }

        Relation commun=this.projection(same);
        Relation commun2=one.projection(same);
        int count=0;
        Vector<Integer> n1=new Vector<Integer>();
        Vector<Integer> n2=new Vector<Integer>();
        for(int i=0;i<commun.getElement().size();i++){
            for(int j=0;j<commun2.getElement().size();j++){
                for(int a=0;a<same.size();a++){
                    for(int b=0;b<same.size();b++){
                        if(commun.attribut.elementAt(a).equals(commun2.attribut.elementAt(b))){
                            if(((Vector<Object>)commun.getElement().elementAt(i)).elementAt(a).equals(((Vector<Object>)commun2.getElement().elementAt(j)).elementAt(b))){
                                count++;
                            }
                        }
                    }
                }
                if(count==same.size()){
                    n1.addElement(i);
                    n2.addElement(j);
                }
            }
        }

        Vector<Vector<Object>> mama=new Vector<Vector<Object>>();
        Vector<Vector<Object>> mama2=new Vector<Vector<Object>>();
        for(int i=0;i<this.getElement().size();i++){
            if(n1.contains(i)){
                mama.addElement((Vector<Object>)this.getElement().elementAt(i));
            }
        }
        for(int i=0;i<one.getElement().size();i++){
            if(n2.contains(i)){
                mama2.addElement((Vector<Object>)one.getElement().elementAt(i));
            }
        }
        Relation mety=new Relation(this.nom, this.attribut, mama);
        Relation mety2=new Relation(this.nom, one.attribut, mama2);
        Relation inona=mety.produitCartesien(mety2);
        for(int i=0;i<inona.getElement().size();i++){
            for(int j=0;j<((Vector<Object>)inona.getElement().elementAt(i)).size();j++){
                for(int a=j+1;a<((Vector<Object>)inona.getElement().elementAt(i)).size();a++){
                    if(inona.attribut.elementAt(j).equals(inona.attribut.elementAt(a))){
                        ((Vector<Object>)inona.getElement().elementAt(i)).remove(j);
                        inona.attribut.remove(j);
                        j--;
                    }
                }
            }
        }
        Relation valiny=new Relation(this.nom, inona.attribut, inona.getElement());
        return valiny;
    }

    public Relation tetaJointure(Relation one, String requete) {
        Relation haha = this.produitCartesien(one);
        Relation mbola = haha.selectionTwo(requete);
        // Ensemble ensemble = haha.difference((Ensemble) mbola);
        // Relation valiny = new Relation(this.nom, haha.attribut, ensemble.getElement());
        return mbola;
    }
    public void afficheRelation() {
        if (this.getElement().isEmpty()) {
            System.out.println("Aucune ligne sélectionnée");
        } else {
            int[] maxColWidths = new int[this.getAttribut().size()];
            
            // Calculer la largeur des colonnes uniquement en fonction des noms des attributs
            for (int i = 0; i < this.getAttribut().size(); i++) {
                maxColWidths[i] = this.getAttribut().elementAt(i).getNom().length() + 2; // Prendre en compte uniquement le nom de l'attribut
            }
            
            // Calculer la largeur maximale en fonction des données de chaque ligne
            for (int i = 0; i < this.getElement().size(); i++) {
                Vector<Object> ligne = (Vector<Object>) this.getElement().elementAt(i);
                for (int j = 0; j < ligne.size(); j++) {
                    int dataLength = ligne.elementAt(j).toString().length();
                    if (dataLength > maxColWidths[j]) {
                        maxColWidths[j] = dataLength;
                    }
                }
            }
    
            // Construction de l'en-tête sans inclure le domaine (sans les parenthèses)
            String ligneEntete = "";
            for (int i = 0; i < this.getAttribut().size(); i++) {
                String colHeader = this.getAttribut().elementAt(i).getNom(); // Ne pas inclure le domaine
                ligneEntete += String.format("%-" + maxColWidths[i] + "s", colHeader);
                if (i < this.getAttribut().size() - 1) {
                    ligneEntete += " | ";
                }
            }
            System.out.println(ligneEntete);
            System.out.println("-".repeat(ligneEntete.length()));
    
            // Affichage des lignes de données
            for (int i = 0; i < this.getElement().size(); i++) {
                Vector<Object> ligne = (Vector<Object>) this.getElement().elementAt(i);
                for (int j = 0; j < ligne.size(); j++) {
                    System.out.print(String.format("%-" + maxColWidths[j] + "s", ligne.elementAt(j)));
                    if (j < ligne.size() - 1) {
                        System.out.print(" | ");
                    }
                }
                System.out.println();
            }
        }
    }
    
    
}
