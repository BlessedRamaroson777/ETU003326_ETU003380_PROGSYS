package fitambarana;
import java.lang.Object;
import java.util.*;

public class Ensemble{
    Vector<Object> element=new Vector<>();

    public Ensemble(Vector e){
        PasDeDoublon(e);
        this.element=e;
    }

    public Vector getElement(){
        return this.element;
    }

    public void add(Object a){
        if(!this.element.contains(a)){
            this.element.addElement(a);
        }
    }

    public void setElement(Vector<Object> a){
        this.element=a;
    }

    public void PasDeDoublon(Vector e) {
        if (e != null) {
            Set<Object> set = new HashSet<>(e);
            e.clear(); 
            e.addAll(set); 
        }
    }

    public Ensemble atambatra(Ensemble a){
        Ensemble miaraka=new Ensemble(this.getElement());
        for(int i=0;i<a.getElement().size();i++){
            miaraka.add(a.getElement().elementAt(i));
        }
        return miaraka;
    }

    public boolean appartenance(Object element){
        for(int i=0;i<this.getElement().size();i++){
            if(this.getElement().elementAt(i)==element){
                return true;
            }
        }
        return false;
    }

    public int cardinal(){
        return this.element.size();
    }

    public Ensemble union(Ensemble a){
        Ensemble miaraka=atambatra(a);
        miaraka.PasDeDoublon(miaraka.getElement());
        return miaraka;
    }

    public Ensemble intersection(Ensemble a){
        Vector<Object> element=new Vector<>();
        for(int i=0;i<this.getElement().size();i++){
            for(int j=0;j<a.getElement().size();j++){
                if(this.getElement().elementAt(i).equals(a.getElement().elementAt(j))){
                    element.addElement(this.getElement().elementAt(i));
                }
            }
        }
        Ensemble e=new Ensemble(element);
        return e;
    }
    
    public Ensemble difference(Ensemble a) {
        Ensemble inter = this.intersection(a);
        Vector<Object> result = new Vector<>(this.getElement()); 
    
        for (Object elem : inter.getElement()) {
            result.removeIf(e -> e.equals(elem)); 
        }
    
        return new Ensemble(result);
    }
    
}
