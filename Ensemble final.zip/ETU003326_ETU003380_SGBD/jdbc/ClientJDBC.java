package jdbc;

import java.sql.*;

public class ClientJDBC {
    public static void main(String[] args) {
        try {
            // Enregistrer le driver JDBC personnalisé
            Class.forName("monSGBD.jdbc.MonDriver");

            // Se connecter à ton SGBD personnalisé via JDBC
            Connection conn = DriverManager.getConnection("monsgbd://localhost:12345", "utilisateur", "motdepasse");

            // Créer un Statement pour exécuter une requête SQL
            Statement stmt = conn.createStatement();

            // Exécuter une requête SELECT et récupérer les résultats dans un ResultSet
            ResultSet rs = stmt.executeQuery("SELECT * FROM ma_table");

            // Traiter les résultats
            while (rs.next()) {
                System.out.println("Colonne 1: " + rs.getString(1));
            }

            // Fermer les objets JDBC
            rs.close();
            stmt.close();
            conn.close();

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
}