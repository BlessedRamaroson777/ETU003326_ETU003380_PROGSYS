package jdbc;

import java.sql.*;
import java.util.Properties;
import java.util.logging.Logger;

public class MonDriver implements Driver {

    static {
        try {
            // Enregistrement du driver lors du démarrage de l'application
            DriverManager.registerDriver(new MonDriver());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Connection connect(String url, Properties info) throws SQLException {
        if (url == null || !url.startsWith("monsgbd://")) {
            throw new SQLException("URL invalide");
        }
        return new MonConnection(url);
    }

    @Override
    public boolean acceptsURL(String url) throws SQLException {
        return url != null && url.startsWith("monsgbd://");
    }

    @Override
    public DriverPropertyInfo[] getPropertyInfo(String url, Properties info) throws SQLException {
        return new DriverPropertyInfo[0]; // Pas de propriétés à gérer pour l'instant
    }

    @Override
    public int getMajorVersion() {
        return 1;
    }

    @Override
    public int getMinorVersion() {
        return 0;
    }

    @Override
    public boolean jdbcCompliant() {
        return false; // Ici, on n'implémente pas la conformité complète JDBC
    }

    @Override
    public Logger getParentLogger() {
        return Logger.getLogger(MonDriver.class.getName());
    }
}