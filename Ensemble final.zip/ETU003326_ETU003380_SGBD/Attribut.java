package firaisana;

import java.util.Vector;

import fitambarana.Ensemble;

public class Attribut {
    String nom;
    Class domaine;
    Ensemble ensDomaine;
    public Attribut(String nom, Class domaine, Ensemble ensDomaine){
        this.nom=nom;
        this.domaine=domaine;
        this.ensDomaine=ensDomaine;
    }  
    public Attribut(String nom, Ensemble ensDomaine){
        this.nom=nom;
        this.domaine=null;
        this.ensDomaine=ensDomaine;
    }  
    public Attribut(String nom, Class domaine){
        this.nom=nom;
        this.domaine=domaine;
        this.ensDomaine=null;
    }  
    public Attribut(){
    }  
    public void changeDomaine(Class change, Ensemble ens){
        this.domaine=change;
        this.ensDomaine=ens;
    }
    public String getNom(){
        return this.nom;
    }
    public void setNom(String name){
        this.nom=name;
    }
    public void setDomaine(Class place){
        this.domaine=place;
    }
    public boolean equals(Attribut one){
        if(this.getNom()==one.getNom() && (this.getDomaine()==one.getDomaine() || this.getEnsDomaine()==one.getEnsDomaine())){
            return true;
        }
        return false;
    }
    public Class getDomaine(){
        return this.domaine;
    }
    public Ensemble getEnsDomaine(){
        return this.ensDomaine;
    }
    
    public boolean isValid(Object check) {

        if(check==null){
            return true;
        }

        if (this.domaine != null) {
            if (check.getClass() == this.getDomaine()) {
                return true;
            } else {
                // Essayer de convertir l'objet en domaine
                if (this.getDomaine().isAssignableFrom(check.getClass()) || check.toString() != null) {
                    return true;
                }
            }
        }
        
        if (this.ensDomaine != null && this.ensDomaine.getElement() != null) {
            if (this.ensDomaine.getElement().contains(check)) {
                return true;
            }
        }
        return false;
    }
    

    public Vector<Vector<Object>> nupletValid(Vector<Attribut> att, Vector<Vector<Object>> nup) {
        Vector<Vector<Object>> validNuplets = new Vector<Vector<Object>>();
        int j=1;
        for (Vector<Object> tuple : nup) {
            j++;
            boolean isValid = true;
            for (int i = 0; i < att.size(); i++) {
                if (!att.get(i).isValid(tuple.get(i))) {
                    isValid = false;
                    break;
                }
            }
            if (isValid) {
                validNuplets.add(tuple);
            }
            if(!isValid){
                System.out.println("l'element numero "+j+" n'est pas valide. ");
            }
        }
        return validNuplets;
    }
}
