package socket;

import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.Date;

import firaisana.Relation;

public class Server {
    private static int requestCounter = 0; // Compteur de requêtes

    public static void main(String[] args) {
        int port = 12345;

        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Serveur démarré sur le port " + port);

            // Boucle principale pour accepter les connexions clients
            while (true) {
                try {
                    // Accepter une nouvelle connexion client
                    Socket clientSocket = serverSocket.accept();
                    System.out.println("Client connecté");

                    // Lancer un thread pour gérer ce client
                    new Thread(new ClientHandler(clientSocket)).start();

                } catch (IOException e) {
                    System.err.println("Erreur lors de l'acceptation du client : " + e.getMessage());
                }
            }
        } catch (IOException e) {
            System.err.println("Erreur serveur : " + e.getMessage());
        }
    }

    static class ClientHandler implements Runnable {
        private Socket clientSocket;
        private String userDirectory = null; // Répertoire de l'utilisateur (créé après authentification)

        public ClientHandler(Socket clientSocket) {
            this.clientSocket = clientSocket;
        }

        @Override
        public void run() {
            try (
                BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)
            ) {
                out.println("Veuillez saisir une commande ('use username,password' pour se connecter ou 'create username,password' pour créer un compte) :");
                String credentials = in.readLine();
                String[] parts = credentials.split(" ", 2); // Divise la commande en 2 parties : commande et arguments

                if (parts.length != 2) {
                    out.println("Format de commande incorrect. Connexion terminée.");
                    return; // Fermer la connexion si le format est incorrect
                }

                String command = parts[0].trim();
                String[] credentialsParts = parts[1].split(",");
                if (credentialsParts.length != 2) {
                    out.println("Format de username,password incorrect. Connexion terminée.");
                    return;
                }

                String username = credentialsParts[0].trim();
                String password = credentialsParts[1].trim();

                if ("use".equalsIgnoreCase(command)) {
                    if (!validateUser(username, password)) {
                        out.println("Authentification échouée. Connexion terminée.");
                        return; // Fermer la connexion
                    }
                    out.println("Authentification réussie.");
                    createUserDirectory(username);
                    this.userDirectory = username;

                } else if ("create".equalsIgnoreCase(command)) {
                    if (userExists(username)) {
                        out.println("Le nom d'utilisateur existe déjà. Veuillez choisir un autre nom.");
                        return;
                    }
                    if (createUser(username, password)) {
                        createUserDirectory(username); // Crée le dossier après la création de l'utilisateur
                        out.println("Compte créé avec succès.");
                    } else {
                        out.println("Erreur lors de la création du compte. Veuillez réessayer.");
                        return;
                    }
                } else {
                    out.println("Commande inconnue. Connexion terminée.");
                    return;
                }

                out.println("Entrez une requête (ou 'bye' pour quitter) :");
                String userRequest;
                while ((userRequest = in.readLine()) != null) {
                    requestCounter++;

                    if ("bye".equalsIgnoreCase(userRequest)) {
                        out.println("Au revoir!");
                        out.flush(); // S'assurer que le message est envoyé immédiatement
                        in.close(); // Fermer le flux d'entrée
                        out.close(); // Fermer le flux de sortie
                        clientSocket.close(); // Fermer le socket
                        break; // Sortir de la boucle
                    }

                    String result = requeteTraitee(userRequest, username);
                    out.println(result);
                }
            } catch (IOException e) {
                System.err.println("Erreur lors de la gestion du client : " + e.getMessage());
            } finally {
                try {
                    clientSocket.close();
                } catch (IOException e) {
                    System.err.println("Erreur lors de la fermeture de la connexion client : " + e.getMessage());
                }
            }
        }

        private boolean validateUser(String username, String password) {
            File userFile = new File("utilisateur/liste/user.txt");

            try (BufferedReader reader = new BufferedReader(new FileReader(userFile))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] credentials = line.split(",");
                    if (credentials.length == 2) {
                        String fileUsername = credentials[0].trim();
                        String filePassword = credentials[1].trim();

                        if (username.equals(fileUsername) && password.equals(filePassword)) {
                            return true;
                        }
                    }
                }
            } catch (IOException e) {
                System.err.println("Erreur lors de la lecture du fichier utilisateur : " + e.getMessage());
            }
            return false;
        }

        private boolean userExists(String username) {
            File userFile = new File("utilisateur/liste/user.txt");
            try (BufferedReader reader = new BufferedReader(new FileReader(userFile))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] credentials = line.split(",");
                    if (credentials.length == 2 && credentials[0].trim().equals(username)) {
                        return true; // L'utilisateur existe déjà
                    }
                }
            } catch (IOException e) {
                System.err.println("Erreur lors de la vérification de l'utilisateur : " + e.getMessage());
            }
            return false;
        }

        private boolean createUser(String username, String password) {
            File userFile = new File("utilisateur/liste/user.txt");
            try (FileWriter writer = new FileWriter(userFile, true);
                 BufferedWriter bufferedWriter = new BufferedWriter(writer)) {
                bufferedWriter.write(username + "," + password);
                bufferedWriter.newLine();
                return true;
            } catch (IOException e) {
                System.err.println("Erreur lors de la création de l'utilisateur : " + e.getMessage());
            }
            return false;
        }

        public String requeteTraitee(String requete, String user) {
            ByteArrayOutputStream sortieTemporaire = new ByteArrayOutputStream();
            PrintStream fluxOriginal = System.out; // Sauvegarde de la sortie standard originale
            System.setOut(new PrintStream(sortieTemporaire)); // Redirection de la sortie

            try {
                new Relation().request(requete + ";" + user);
                logRequest(requete, user);
                return sortieTemporaire.toString();
            } finally {
                System.setOut(fluxOriginal);
            }
        }

        private void createUserDirectory(String username) throws IOException {
            File userDir = new File(username);
            if (!userDir.exists()) {
                if (userDir.mkdir()) {
                    System.out.println("Dossier utilisateur créé : " + username);
                } else {
                    throw new IOException("Impossible de créer le dossier utilisateur : " + username);
                }
            }
        }

        private void logRequest(String request, String userDirectory) {
            try {
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String timestamp = dateFormat.format(new Date());

                File logFile = new File(userDirectory + "/historique_requetes.txt");

                if (!logFile.exists()) {
                    logFile.createNewFile();
                }

                try (FileWriter fileWriter = new FileWriter(logFile, true);
                     BufferedWriter bufferedWriter = new BufferedWriter(fileWriter)) {
                    bufferedWriter.write("Requête #" + requestCounter + " - " + timestamp + " : " + request);
                    bufferedWriter.newLine();
                }

            } catch (IOException e) {
                System.err.println("Erreur lors de l'enregistrement de la requête : " + e.getMessage());
            }
        }
    }
}
