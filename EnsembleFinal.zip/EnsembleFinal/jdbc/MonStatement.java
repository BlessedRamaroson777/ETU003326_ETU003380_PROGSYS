package jdbc;

import java.sql.*;

public class MonStatement implements Statement {

    @Override
    public ResultSet executeQuery(String sql) throws SQLException {
        if (sql.startsWith("SELECT")) {
            return new MonResultSet();  // Retourne un ResultSet simulé
        }
        return null;
    }

    @Override
    public int executeUpdate(String sql) throws SQLException {
        return 0;  // Non implémenté, renvoie juste 0
    }

    @Override
    public void close() throws SQLException {
        System.out.println("Statement fermé.");
    }

    @Override
    public int getMaxFieldSize() throws SQLException {
        return 0;  // Non implémenté
    }

    @Override
    public void setMaxFieldSize(int max) throws SQLException {
        // Non implémenté
    }

    @Override
    public int getQueryTimeout() throws SQLException {
        return 0;  // Non implémenté
    }

    @Override
    public void setQueryTimeout(int seconds) throws SQLException {
        // Non implémenté
    }

    @Override
    public void cancel() throws SQLException {
        // Non implémenté
    }

    @Override
    public SQLWarning getWarnings() throws SQLException {
        return null;  // Non implémenté
    }

    @Override
    public void clearWarnings() throws SQLException {
        // Non implémenté
    }

    @Override
    public void setCursorName(String name) throws SQLException {
        // Non implémenté
    }

    @Override
    public boolean execute(String sql) throws SQLException {
        return sql.startsWith("SELECT");  // Pour simplifier
    }

    @Override
    public ResultSet getResultSet() throws SQLException {
        return new MonResultSet();  // Résultat simulé
    }

    @Override
    public int getUpdateCount() throws SQLException {
        return 0;  // Non implémenté
    }

    @Override
    public boolean getMoreResults() throws SQLException {
        return false;  // Non implémenté
    }

    @Override
    public void setFetchDirection(int direction) throws SQLException {
        // Non implémenté
    }

    @Override
    public int getFetchDirection() throws SQLException {
        return 0;  // Non implémenté
    }

    @Override
    public void setFetchSize(int rows) throws SQLException {
        // Non implémenté
    }

    @Override
    public int getFetchSize() throws SQLException {
        return 0;  // Non implémenté
    }

    @Override
    public int getResultSetConcurrency() throws SQLException {
        return 0;  // Non implémenté
    }

    @Override
    public int getResultSetType() throws SQLException {
        return 0;  // Non implémenté
    }

    @Override
    public void addBatch(String sql) throws SQLException {
        // Non implémenté
    }

    @Override
    public void clearBatch() throws SQLException {
        // Non implémenté
    }

    @Override
    public int[] executeBatch() throws SQLException {
        return new int[0];  // Non implémenté
    }

    @Override
    public Connection getConnection() throws SQLException {
        return null;  // Non implémenté
    }

    @Override
    public boolean getMoreResults(int current) throws SQLException {
        return false;  // Non implémenté
    }

    @Override
    public ResultSet getGeneratedKeys() throws SQLException {
        return null;  // Non implémenté
    }

    // Implémenter d'autres méthodes si nécessaire...
}