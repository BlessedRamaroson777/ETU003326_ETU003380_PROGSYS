package fitambarana;

import java.util.Vector;

import org.w3c.dom.Attr;

import firaisana.Attribut;
import firaisana.Relation;
import save.*;
import fitambarana.Ensemble;

public class TestEnsemble {
    public static void main(String[] args){
        Vector<Attribut> cjhA=new Vector<Attribut>();
        cjhA.addElement(new Attribut("IdCours", String.class));
        cjhA.addElement(new Attribut("Jour", String.class));
        cjhA.addElement(new Attribut("Heure", String.class));
        Vector<Vector<Object>> cjhO=new Vector<Vector<Object>>();
        Vector<Object> ligne1=new Vector<Object>();
        ligne1.addElement("Archi");
        ligne1.addElement("Lu");
        ligne1.addElement("9h");
        cjhO.add(ligne1);
        Vector<Object> ligne2=new Vector<Object>();
        ligne2.addElement("Algo");
        ligne2.addElement("Ma");
        ligne2.addElement("9h");
        cjhO.add(ligne2);
        Vector<Object> ligne3=new Vector<Object>();
        ligne3.addElement("Algo");
        ligne3.addElement("Ven");
        ligne3.addElement("9h");
        cjhO.add(ligne3);
        Vector<Object> ligne4=new Vector<Object>();
        ligne4.addElement("Syst");
        ligne4.addElement("Ma");
        ligne4.addElement("14h");
        cjhO.add(ligne4);

        Vector<Attribut> csA=new Vector<Attribut>();
        csA.addElement(new Attribut("IdCours", String.class));
        csA.addElement(new Attribut("IdSalle", String.class));
        Vector<Vector<Object>> csO=new Vector<Vector<Object>>();
        Vector<Object> ligne5=new Vector<Object>();
        ligne5.addElement("Archi");
        ligne5.addElement("S1");
        csO.add(ligne5);
        Vector<Object> ligne6=new Vector<Object>();
        ligne6.addElement("Algo");
        ligne6.addElement("S2");
        csO.add(ligne6);
        Vector<Object> ligne7=new Vector<Object>();
        ligne7.addElement("Syst");
        ligne7.addElement("S1");
        csO.add(ligne7);

        Vector<Attribut> enaA=new Vector<Attribut>();
        enaA.addElement(new Attribut("IdEtudiant", Integer.class));
        enaA.addElement(new Attribut("Nom", String.class));
        enaA.addElement(new Attribut("Adresse", String.class));
        Vector<Vector<Object>> enaO=new Vector<Vector<Object>>();
        Vector<Object> ligne8=new Vector<Object>();
        ligne8.addElement(100);
        ligne8.addElement("Toto");
        ligne8.addElement("Nice");
        enaO.add(ligne8);
        Vector<Object> ligne9=new Vector<Object>();
        ligne9.addElement(200);
        ligne9.addElement("Tata");
        ligne9.addElement("Paris");
        enaO.add(ligne9);
        Vector<Object> ligne10=new Vector<Object>();
        ligne10.addElement(300);
        ligne10.addElement("Titi");
        ligne10.addElement("Rome");
        enaO.add(ligne10);

        Relation cjh=new Relation("cjh",cjhA,cjhO);

        Vector<Attribut> cenA=cjh.attributString("IdCours String, IdEtudiant Integer, Note String");
        // Vector<Attribut> cenA=new Vector<Attribut>();
        // cenA.addElement(new Attribut("IdCours", String.class));
        // cenA.addElement(new Attribut("IdEtudiant", Integer.class));
        // cenA.addElement(new Attribut("Note", String.class));
        Vector<Vector<Object>> cenO=new Vector<Vector<Object>>();
        Vector<Object> ligne11=new Vector<Object>();
        ligne11.addElement("Archi");
        ligne11.addElement(100);
        ligne11.addElement("A");
        cenO.add(ligne11);
        Vector<Object> ligne12=new Vector<Object>();
        ligne12.addElement("Archi");
        ligne12.addElement(300);
        ligne12.addElement("A");
        cenO.add(ligne12);
        Vector<Object> ligne13=new Vector<Object>();
        ligne13.addElement("Syst");
        ligne13.addElement(100);
        ligne13.addElement("B");
        cenO.add(ligne13);
        Vector<Object> ligne14=new Vector<Object>();
        ligne14.addElement("Syst");
        ligne14.addElement(200);
        ligne14.addElement("A");
        cenO.add(ligne14);
        Vector<Object> ligne15=new Vector<Object>();
        ligne15.addElement("Syst");
        ligne15.addElement(300);
        ligne15.addElement("B");
        cenO.add(ligne15);
        Vector<Object> ligne16=new Vector<Object>();
        ligne16.addElement("Algo");
        ligne16.addElement(100);
        ligne16.addElement("C");
        cenO.add(ligne16);
        Vector<Object> ligne17=new Vector<Object>();
        ligne17.addElement("Algo");
        ligne17.addElement(200);
        ligne17.addElement("A");
        cenO.add(ligne17);

        Relation cs=new Relation("cs",csA,csO);
        Relation ena=new Relation("ena",enaA,enaO);
        Relation cen=new Relation("cen",cenA,cenO);
        // cen.afficheRelation();
        // cen.deleteTableString("drop table cen");
        // cen.getAllTable("show tables");
        // cen.request("select from cen where IdEtudiant=300");
        // cen.request("alter table cen to Matiere IdCours");
        cen.request("show tables;user");

        // cen.request("select IdEtudiant from cen");
        // cen.selectString("select from cen where IdEtudiant=300").afficheRelation();
        // cen.writeToFile(cen);
        // Relation test=cen.selectionLiaison("(IdCours=Algo) and (IdEtudiant=100)");
        // test.afficheRelation();
        //question1
        Vector<String> v1=new Vector<String>();
        v1.add("IdCours");
        Relation r1=cjh.projection(v1);
        // r1.afficheRelation();
        // System.out.println();
        Vector<String> v2=new Vector<String>();
        v2.add("IdEtudiant");
        Relation r2=ena.projection(v2);
        // r2.afficheRelation();
        // System.out.println();
        Relation ra=cen.selectionLiaison("(IdCours=Algo)");
        // ra.afficheRelation();
        // System.out.println();
        Relation rb=cjh.tetaJointure(cs, "IdCours=IdCours");
        // rb.afficheRelation();
        // System.out.println();
        //question 14

        //r1
        //r2
        Vector<String> v3=new Vector<String>();
        v3.add("IdEtudiant");
        v3.add("IdCours");
        Relation r3=cen.projection(v3);
        // r3.afficheRelation();
        // System.out.println();
        Relation r7=r2.produitCartesien(r1);
        // r7.afficheRelation();
        // System.out.println();
        Relation r8 = r7.difference(r3);
        // r8.afficheRelation();
        // System.out.println();
        Vector<String> v4=new Vector<String>();
        v4.add("IdEtudiant");
        Relation r9 = r3.projection(v4);
        // r9.afficheRelation();
        // System.out.println();
        Relation r10 = r8.projection(v4);
        // r10.afficheRelation();
        // System.out.println();
        Relation r11 = r9.difference(r10);
        // r11.afficheRelation();

        


        Vector<Object> meh=new Vector<Object>();
        String no="He is faithful";
        int n=6;
        meh.addElement(no);
        meh.addElement(n);
        Ensemble nein=new Ensemble(meh);
        Vector<Attribut> inonaTy=new Vector<Attribut>();
        inonaTy.addElement(new Attribut("Nom", Boolean.class, nein));
        inonaTy.addElement(new Attribut("Compte", Integer.class));
        Vector<Vector<Object>> nup=new Vector<Vector<Object>>();
        Vector<Object> first=new Vector<Object>();
        first.addElement(false);
        first.addElement(100);
        nup.addElement(first);
        Relation testamenta=new Relation("testamenta",inonaTy, nup);

        
        Vector<Object> meh2=new Vector<Object>();
        double flot=2.6;
        double flot2=10.7;
        meh2.add(flot);
        meh2.add(flot2);
        Ensemble nein2=new Ensemble(meh2);
        Vector<Attribut> inonaTy2=new Vector<Attribut>();
        inonaTy2.addElement(new Attribut("Mais", nein2));
        inonaTy2.addElement(new Attribut("Yeah", Boolean.class, nein2));
        Vector<Vector<Object>> nup2=new Vector<Vector<Object>>();
        Vector<Object> no1=new Vector<Object>();
        no1.addElement(2.6);
        no1.addElement(true);
        nup2.addElement(no1);
        Relation testVaovao=new Relation("testVaovao",inonaTy2, nup2);
        Relation right=testamenta.union(testVaovao);
        // for(int i=0;i<right.getAttribut().size();i++){
        //     System.out.println("-"+right.getAttribut().elementAt(i).getDomaine());
        //     for(int j=0;j<right.getAttribut().elementAt(i).getEnsDomaine().getElement().size();j++){
        //         System.out.println(right.getAttribut().elementAt(i).getEnsDomaine().getElement().elementAt(j));
        //     }
        //     System.out.println();
        // }
        // right.afficheRelation();
            // System.out.println(new Attribut("Blessed", String.class).isValid(true));
    }
}
