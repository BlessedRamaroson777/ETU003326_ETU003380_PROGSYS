package socket;

import java.io.*;
import java.net.*;

public class Client {
    public static void main(String[] args) {
        String host = "localhost";
        int port = 12345;

        try (
            Socket socket = new Socket(host, port);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader consoleInput = new BufferedReader(new InputStreamReader(System.in))
        ) {
            System.out.println("Connecté au serveur sur " + host + ":" + port);

            String serverMessage = null; // Initialisation par défaut
            StringBuilder fullMessage = new StringBuilder(); // Pour stocker les messages du serveur

            while (true) {
                // Lire toutes les lignes disponibles du serveur avant d'attendre une saisie
                while (in.ready() || fullMessage.length() == 0) {
                    serverMessage = in.readLine();
                    if (serverMessage != null) {
                        fullMessage.append(serverMessage).append("\n");
                    }
                }
            
                // Afficher tout le message reçu du serveur
                System.out.print(fullMessage.toString());
                fullMessage.setLength(0); // Réinitialiser le contenu pour la prochaine itération
            
                // Si le serveur envoie un message de déconnexion
                if (serverMessage != null && serverMessage.trim().equalsIgnoreCase("Authentification échouée. Connexion terminée.")) {
                    System.out.println("Déconnexion du serveur.");
                    break; // Sortir de la boucle et fermer la connexion
                }
            
                // Si le message du serveur est "Au revoir!", fermer proprement
                if (serverMessage != null && serverMessage.trim().equalsIgnoreCase("Au revoir!")) {
                    System.out.println("Déconnexion du serveur.");
                    break; // Sortir de la boucle
                }
            
                // Si le serveur demande une saisie, attendre une entrée utilisateur
                System.out.print("> "); // Indicateur d'entrée utilisateur
                String userInput = consoleInput.readLine(); // Lecture de l'entrée utilisateur
                if (userInput != null && !userInput.trim().isEmpty()) {
                    out.println(userInput); // Envoie l'entrée au serveur
                } else {
                    System.out.println("Entrée vide, veuillez réessayer.");
                }
            }
            
        } catch (IOException e) {
            System.err.println("Erreur côté client : " + e.getMessage());
        }
    }
}
